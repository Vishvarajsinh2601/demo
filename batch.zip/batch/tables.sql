CREATE TABLE `sales` (                  
          `Name` varchar(200) NOT NULL,         
          `City` varchar(200) NOT NULL,         
          PRIMARY KEY  (`Name`,`City`)          
        ) 